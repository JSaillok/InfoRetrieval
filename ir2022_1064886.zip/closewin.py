def close_windows(*windows):
    for window in windows:
        window.destroy()